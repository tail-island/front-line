npm --silent run play "python ../python-example/run.py" "node ./src/cli/adapter.js operationPhalanx" 1

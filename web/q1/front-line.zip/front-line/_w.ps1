npm run webSocket "node ./src/cli/adapter.js operationPhalanx"

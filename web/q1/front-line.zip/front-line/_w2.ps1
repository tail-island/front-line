npm run webSocket "python ../python-example/run.py"

npm --silent run play "node ./src/cli/adapter.js operationFirstLegalAction" "node ./src/cli/adapter.js operationPhalanx" 1
